/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   prompt copy.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: femorell <femorell@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/01/29 18:43:54 by femorell          #+#    #+#             */
/*   Updated: 2024/01/30 15:24:33 by femorell         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

void	find_escape(char *str, char *escape_type)
{
	int i;

	if (*escape_type == '\\')
		*escape_type = 0;
	if (*escape_type == '|')
	{	
		i = 0;
		while (str[i] && ft_isspace(str[i]))
			i++;
		if (!str[i] || ft_isspace(str[i]))
			return ;
		if (str[i] == '|')
		{
			*escape_type = 0;
			return ;
		}
		*escape_type = 0;
	}
	i = 0;
	while (str[i])
	{
		if (!*escape_type && (str[i] == '\'' || str[i] == '"' || str[i] == '`'))
			*escape_type = str[i];
		else if (*escape_type == str[i])
			*escape_type = 0;
		if (!*escape_type && str[i] == '\\' && !str[i + 1])
			*escape_type = str[i];
		if (!*escape_type && str[i] == '|')
		{
			while (str[i + 1] && ft_isspace(str[i + 1]))
				i++;
			if (!str[i + 1])
				*escape_type = '|';
		}
		i++;
	}
}

void	escape_quote(char *next_line, char **input, char escape_type)
{
	char *temp;

	if (escape_type == '\'' || escape_type == '"' || escape_type == '`')
	{
		temp = *input;
		*input = ft_strjoin(*input, "\n");
		free(temp);
		temp = *input;
		*input = ft_strjoin(*input, next_line);
		free(temp);
	}
}

void	escape_backslash(char *next_line, char **input, char escape_type)
{
	char *temp;

	if (escape_type == '\\')
	{
		temp = *input;
		*input = ft_substr(*input, 0, ft_strlen(*input) - 1);
		free(temp);
		temp = *input;
		*input = ft_strjoin(*input, next_line);
		free(temp);
	}
}

void	escape_pipe(char *next_line, char **input, char escape_type)
{
	char *temp;

	if (escape_type == '|' && *next_line)
	{
		temp = *input;
		*input = ft_strjoin(*input, " ");
		free(temp);
		temp = *input;
		*input = ft_strjoin(*input, next_line);
		free(temp);
	}
}

void	print_prompt(char **input)
{
	char *next_line;
	//char *temp;
	char	escape_type = 0;

	*input = readline("\033[34;1mbunnyfox$\033[0m ");
	if (!*input) 
	{
		printf("exit\n");
		exit(0);
	}
	find_escape(*input, &escape_type);
	while (escape_type)
	{
		next_line = readline("> ");
		if (!next_line)
		{
			if (escape_type != '\\' && escape_type != '|')
				printf("minishell: unexpected EOF while looking for matching `%c'\n", escape_type);
			if (escape_type != '\\')
			{
				print_error("syntax error", NULL, "unexpected end of file");
				if (escape_type == '|')
				{
					ft_putstr_fd("exit\n", 2);
					exit(2);
				}
			}
			escape_type = 0;
			exit_status(NULL, 2);
			break;
		}
		escape_quote(next_line, input, escape_type);
		escape_backslash(next_line, input, escape_type);
		escape_pipe(next_line, input, escape_type);
		// if (escape_type == '\'' || escape_type == '"' || escape_type == '`')
		// {
		// 	temp = *input;
		// 	*input = ft_strjoin(*input, "\n");
		// 	free(temp);
		// 	temp = *input;
		// 	*input = ft_strjoin(*input, next_line);
		// 	free(temp);
		// }
		// if (escape_type == '\\')
		// {
		// 	temp = *input;
		// 	*input = ft_substr(*input, 0, ft_strlen(*input) - 1);
		// 	free(temp);
		// 	temp = *input;
		// 	*input = ft_strjoin(*input, next_line);
		// 	free(temp);
		// }
		// if (escape_type == '|' && *next_line)
		// {
		// 	temp = *input;
		// 	*input = ft_strjoin(*input, " ");
		// 	free(temp);
		// 	temp = *input;
		// 	*input = ft_strjoin(*input, next_line);
		// 	free(temp);
		// }
		find_escape(next_line, &escape_type);
		free(next_line);
	}
	if (**input)
		add_history(*input);
}
